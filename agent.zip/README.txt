PALAK UNISEX SALON — MOBILE-FIRST WEBSITE
=========================================

FILES
- index.html                 Complete single-file website (HTML + embedded CSS + JS)
- assets/img1.jpg            Bridal hero photograph
- assets/img2.jpg            Salon interior photograph
- assets/img3.jpg            Hair styling photograph
- assets/img4.jpg            Mehndi / bridal detail photograph
- assets/solo.mp3            Empty placeholder — replace with your MP3 song

UPLOAD
Upload index.html and the complete assets folder together to your hosting.
Do not rename the image or music files.

MUSIC
Replace assets/solo.mp3 with your own MP3 file. Visitors tap the floating music
button to start playback. Browsers generally block sound autoplay until a visitor
interacts with the page.

MOBILE LAYOUT
Designed phone-first: compact first-screen hero, stable navigation, no horizontal
scrolling, 2-column service cards, responsive gallery, and lightweight scroll reveals.
The page scrolls vertically between sections so visitors can reach services,
gallery, reviews, and contact details.
